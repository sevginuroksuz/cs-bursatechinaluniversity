CREATE DATABASE `sifreligiris` DEFAULT CHARACTER SET utf8 COLLATE 
utf8_turkish_ci; 

USE `sifreligiris`; 

CREATE TABLE `kullanicilar` 
  ( 
     `id`           INT(11) NOT NULL auto_increment, 
     `kullaniciadi` VARCHAR(255) NOT NULL, 
     `eposta`       VARCHAR(255) NOT NULL, 
     `sifre`        VARCHAR(255) NOT NULL, 
     PRIMARY KEY (`id`) 
  ); 