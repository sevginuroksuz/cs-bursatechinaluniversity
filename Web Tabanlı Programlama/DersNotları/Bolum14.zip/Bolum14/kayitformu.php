<html>
   <!-- türkçe karakter desteği ayarı --> 
   <meta http-equiv="Content-Type"  
      content="text/html; charset=UTF-8" />
   <body>
      <form action="kaydet.php" method="POST"> 
         Adı   : <input type="text" name="ad" />    <br /> 
         Soyadı: <input type="text" name="soyad" /> <br /> 
         Birim : <input type="text" name="birim" /> <br /> 
         Maaş  : <input type="text" name="maas" />  <br /> 
         <input type="submit" value="KAYDET"/> 
      </form>
   </body>
</html>