<html>
<head><meta charset="utf-8"></head>
<body>
<?php
//mysql baglanti kodunu ekliyoruz
include("mysqlbaglan.php");

//sorguyu hazirliyoruz
$sql = "SELECT * FROM memurlar";

//sorguyu veritabanina gönderiyoruz.
$cevap = mysqli_query($baglanti,$sql);

//eger cevap FALSE ise hata yazdiriyoruz.      
if(!$cevap )
{
    echo '<br>Hata:' . mysqli_error($baglanti);
}

//sorgudan gelen tüm kayitlari tablo içinde yazdiriyoruz.
//önce tablo başlıkları oluşturalım
echo "<table border=1>";
echo "<tr><th>Memur ID</th><th>Adı</th><th>Soyadı</th><th>Birimi</th><th>Maaşı</th></tr>";

//veritabanından gelen cevabı satır satır alıyoruz.
while($gelen=mysqli_fetch_array($cevap))
{
    // veritabanından gelen değerlerle tablo satırları oluşturalım
  echo "<tr><td>".$gelen['memur_id']."</td>";
  echo "<td>".$gelen['ad']."</td>";
  echo "<td>".$gelen['soyad']."</td>";
  echo "<td>".$gelen['birim']."</td>";
  echo "<td>".$gelen['maas']."</td>";
  echo "<td><a href=kayitsil.php?id=".$gelen['memur_id'].">Sil</a></td></tr>";    
}
// tablo kodunu bitirelim.
echo "</table>";

//veritabani baglantisini kapatiyoruz.
mysqli_close($baglanti);
?>

</body>
</html>
