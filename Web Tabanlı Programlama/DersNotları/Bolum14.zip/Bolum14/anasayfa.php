<html>
<body>
<h1> Personel Otomasyonu </h1>
<ul>
<li><a href="kayitformu.php"> Kayıt Gir </a>
<li><a href="listele.php"> Kayıtları Listele </a>
<li><a href="silmelistesi.php"> Kayıt Sil </a>
<li><a href="guncellelistesi.php"> Kayıt Güncelle </a>
<ul>
</body>
</html>
