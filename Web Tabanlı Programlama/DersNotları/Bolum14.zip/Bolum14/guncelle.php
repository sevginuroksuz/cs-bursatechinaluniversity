<?php
//mysql baglanti kodunu ekliyoruz
include("mysqlbaglan.php");

//sorguyu hazirliyoruz
$sql = "SELECT * FROM memurlar WHERE memur_id=".$_GET['id'];

//sorguyu veritabanina gönderiyoruz.
$cevap = mysqli_query($baglanti,$sql);

//eger cevap FALSE ise hata yazdiriyoruz.      
if(!$cevap ){
    echo '<br>Hata:' . mysqli_error($baglanti);
}


//veritabanından gelen cevabı alıyoruz.
$gelen=mysqli_fetch_array($cevap);
?>
<html>
<body>
<form action="guncelkaydet.php?id=<?php echo $_GET['id'] ?>" 
method="POST">
Adı:
<input type="text" name="ad" value="<?php echo $gelen['ad']?>" />    <br />
Soyadı:
<input type="text" name="soyad" value="<?php echo $gelen['soyad'] ?>" /> <br />
Birim :<input type="text" name="birim" 
value="<?php echo $gelen['birim'] ?>" /> <br />
Maaş  : <input type="text" name="maas" 
value="<?php echo $gelen['maas'] ?>" />  <br />
<input type="submit" value="KAYDET"/>
</form>
</body>
</html>
