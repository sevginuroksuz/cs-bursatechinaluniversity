CREATE DATABASE IF NOT EXISTS `personel` DEFAULT CHARACTER SET utf8 COLLATE utf8_turkish_ci;
USE `personel`;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `memurlar` (
  `memur_id` int(4) NOT NULL AUTO_INCREMENT,
  `ad` varchar(25) NOT NULL,
  `soyad` varchar(25) NOT NULL,
  `birim` varchar(20) NOT NULL,
  `maas` int(5) NOT NULL,
  PRIMARY KEY (`memur_id`)
);

