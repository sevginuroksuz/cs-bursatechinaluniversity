# Basit Düzeyde, `C` Dilinde Preprocessing

Preprocessing bir kaynak dosyanın derlenmeden önce tabi tutulduğu işlemlere verilen addır. Bu dosyada bazı preprocessing aşamaları hakkında bilgiler bulunmaktadır.

---

* [Rezerve edilmiş anahtar kelimeler](https://en.wikipedia.org/wiki/C_(programming_language)#Reserved_words):

![rezerve kelimeler](images/reserved_words.png)

---

* `include` anahtar kelimesi:

`include` anahtar kelimesi belirtilen dosyayı, belirtilen satıra yazar. Bunu görmek için bir `.c` dosyası ve bir `.h` dosyası kullanalım.

`main.c`:

```c
int main()
{
	return 0;
```

`suslu_parantez.h`:

```c
}
```

`main.c` dosyasını derlemeye çalıştığımızda derleyici hata veriyor:

```bash
main.c: In function ‘main’:
main.c:3:9: error: expected declaration or statement at end of input
    3 |         return 0;
      |         ^~~~~~
```

Ancak `main.c` dosyasının aşağıdaki gibi değiştirirsek derlemede hata almıyoruz:

```c
int main()
{
	return 0;
#include "suslu_parantez.h"
```

Eğer `C preprocessor` ile `main.c` dosyasını incelersek aşağıdaki çıktıyı görürüz:

```c
# 0 "main.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "main.c"
int main()
{
 return 0;
# 1 "suslu_parantez.h" 1
}
# 5 "main.c" 2
```

Görüldüğü üzere `main` fonksiyonu sonuna süslü parantez eklenmiştir.