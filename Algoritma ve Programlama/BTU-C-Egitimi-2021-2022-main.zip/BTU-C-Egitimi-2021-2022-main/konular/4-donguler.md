# Döngüler

Ana iskelet:

```c
// while dongusu
while (kosul) {
	// kod
}

// for dongusu
for (baslangic_degeri_ayarlama; kosul; iterasyon_islemi) {
	// kod
}
```

Her `for` dongusu `while` ile yazılabilir:

```c
// for dongusu ile yazilmis ornek
for (int i = 0; i < 10; i++) {
	printf("%d\n", i);
}

// while dongusu ile yazilmis hali
int i = 0;
while (i < 10) {
	printf("%d\n", i);
	i++;
}
```

İterasyon yapılacak işlerde `for` döngüsü kullanmak kodun okunabilirliğini artırır.