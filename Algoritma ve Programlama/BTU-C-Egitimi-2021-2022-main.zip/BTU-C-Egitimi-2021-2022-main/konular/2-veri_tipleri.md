## Veri Tipleri

`C` dilindeki bütün veri tiplerinin sayısal karşılığı vardır. Ancak her veri tipi sayısal işlemler için kullanılmayabilir.

Sayısal işler için kullanılan tipler:

* `short int`
* `int`
* `long int`
* `long long int`
* `float`
* `double`

Bu veri tipleri işaretli sayılardır. Eğer başlarına `unsigned` anahtar kelimesi eklenirse sadece pozitif sayıları kapsarlar.

Karakerler için kullanılan veri tip(ler)i:

* `char`

`char` veri tipi de işaretlidir. Başına `unsigned` anahtar kelimesi konulabilir.

Her veri tipinin bir sınırı vardır. C standartlarına göre [bu sınırlar şöyledir](https://en.wikipedia.org/wiki/C_data_types#Main_types):

![veri tipleri](images/veri_tipleri.png)

### Two's Compliment

Peki neden işaretli veri tipleri maksimum kapasitesinin yarısını pozitif, yarısını negatif sayılara ayırmak zorunda? Bunun cevabı donanımda yatmakta. Bilgisayarlar bir sayının negatif olup olmadığını anlamak için msb'yi (most significant bit) işaret biti olarak kullanıyor. Yani 8 bitlik bir sistemde `00000001` pozitif sayı iken, `10000001` negatif sayı olmakta. Peki ilk biti işaret biti yapmak bütün sorunlarımız çözüyor mu? Bunu bir örnek ile deneyelim. 8 bitlik ve işaret bitinin olduğu bir sistemde 3 (`0b00000011`) ile -2 (`0b10000010`) sayısını toplayalım. 10'luk sayı sisteminde cevabın 1 olacağını biliyoruz.

```text
  00000011
+ 10000010
----------
  10000101
```

İkilik sistemde `10000101` sayısı kaça denk geliyor? İlk bitin işaret biti olduğunu biliyoruz. kalan 7 bitin ise gerçek sayı olduğunu da biliyoruz. Kalan 7 biti 10'luk sisteme çevirirsek elimize 5 sayısı geçer. Yani işlemimizin sonucunda -5 cevabını bulduk. Fakat bunun doğru cevap olmadığını biliyoruz.

Matematikçiler bu duruma başka bir çare bulmuşlardır. Bulunan bu işleme [`two's compliment`](https://en.wikipedia.org/wiki/Two%27s_complement) denir.

Bu metoda göre bir sayının eksilisini almak isterseniz bütün bitleri tersine çevirip çıkan sonuca 1 eklemeniz gerekiyor. -2 sayısı için bakacak olursak:

```text
2: 0b00000010
Bitler tersine çevirilince: 0b11111101
Sonuca 1 eklenince: 0b11111110
```

Şimdi işlemimizi yeniden yaparsak:

```text
  00000011
+ 11111110
----------
  00000001
```

Arta kalan bit işlemcideki bir bayrağı setler. Fakat sonuç olduğu gibi kalır.

`0b00000001` sayısını 10'luk sisteme çevirirsek elimize 1 geçer. Cevap az önce yaptığımız işlem ile uyuşuyor.

Peki işaretli sayılarda negatif ve pozitif değer sınırlarının birler basamağı neden aynı değil? Mesela 8 bitlik bir veri tipinde negatif sayılar -128'e kadar uzanırken, pozitif sayılar 127'ye kadar uzanıyor? Bunun sebebi ilk bitin sıfır olması durumunda sayının pozitif sayılması. 0 sayısının da ilk biti sıfır olduğu için 0 sayısı da bir nevi pozitif sayı olarak görülür. Yani hem pozitif, hem de negatif taraf 128 farklı değer alabilir. Peki dizilerin ilk indisinin 0 olduğunu hatırladınız mı?