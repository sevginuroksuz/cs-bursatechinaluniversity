# Koşullu İfadeler

Ana iskelet:

```c
if (kosul) {
	// kod
}
else {
	// kod
}
```

Koşullu ifadelerde kod bloğu `if` anahtar kelimesi ile başlar. Daha sonrasında `else` veya `if else` anahtar kelimesi gelebilir.

Örnek:

```c
#include <stdio.h>

int main()
{
	int x = 10, y = 20;
	if (x == 11) {
		printf("X değeri: %d\n", x);
	}
	else if (y == 21) {
		printf("Y degeri: %d\n", y);
	}
	else {
		printf("X ve Y degeri: %d, %d\n", x, y);
	}
	return 0;
}
```

Çıktı:

```text
X ve Y degeri: 10, 20
```

Bu kod şu şekilde de yazılabilir:

```c
#include <stdio.h>

int main()
{
	int x = 10, y = 20;
	if (x == 11) {
		printf("X değeri: %d\n", x);
	}
	else {
		if (y == 21) {
			printf("Y degeri: %d\n", y);
		}
		else {
			printf("X ve Y degeri: %d, %d\n", x, y);
		}
	}
	return 0;
}
```