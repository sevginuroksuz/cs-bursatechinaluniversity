# Basit Düzeyde, `C` Kodunun Derlenmesi

Bir `C` kodunu çalıştırılabilir hâle getirmek için derleyiciye ihtiyaç duyulur. Popüler olan birkaç `C` derleyicileri şunlardır: `gcc` (GNU C Compiler), `clang`, `Microsoft Visual Studio C Compiler`... Biz `gcc` (Mac OS X için `clang`) kullanacağız.

---

## Kurulum

### Windows

`gcc` derleyicisinin portlarından birini kurun. Bunlara şunlar örnek verilebilir: `MinGW`, `Cygwin`...

* `MinGW` kurulumu:

[Harici türkçe kaynak](https://www.youtube.com/watch?v=MY9UhGOTVfc)

[Harici ingilizce kaynak](https://www.youtube.com/watch?v=WWTocqPrzMk)

[https://sourceforge.net/projects/mingw-w64/files/Toolchains%20targetting%20Win32/Personal%20Builds/mingw-builds/installer/mingw-w64-install.exe/download](https://sourceforge.net/projects/mingw-w64/files/Toolchains%20targetting%20Win32/Personal%20Builds/mingw-builds/installer/mingw-w64-install.exe/download) adresinden `MinGW W64` paketini indirip kurun. Daha sonrasında kurulumun yapıldığı lokasyondaki `bin\` klasörünü `PATH` değişkenine tanıtın.

Adımlar:

1- Kurulum ekranında `Architecture` kısmını bilgisayarınızın mimarisine göre değiştirmeniz gerekmektedir.

![kurulum 1](images/mingw_w64_kurulum_1.png)

2- Kurulum tamamlandıktan sonra `PATH` değişkenini değiştirmemiz gerek. Bu yüzden arama kısmına 'path' yazıyoruz ve resimdeki seçeneği seçiyoruz.

![kurulum 2](images/mingw_w64_kurulum_2.png)

3- Daha sonrasında 'Environment Variables' seçeneğine tıklıyoruz.

![kurulum 3](images/mingw_w64_kurulum_3.png)

4- Buradan 'System Variables' sekmesinden 'Path' değişkenine tıklayıp düzenle diyoruz.

![kurulum 4](images/mingw_w64_kurulum_4.png)

5- Daha sonrasında 'New' seçeneğine tıklayarak kurulumun yapıldığı klasördeki `bin\` klasörünün adresini yapıştırıyoruz.

![kurulum 5](images/mingw_w64_kurulum_5.png)

#### Windows'ta Bir Klasörü Komut Satırında Açmak

1- Kaynak dosyam masaüstünde olduğu için dosya yöneticisinden masaüstünü açıyorum.

![wkomut 1](images/wkomut_1.png)

2- Daha sonrasında dosyaların üstünde bulunan adres çubuğuna `cmd` yazıyorum.

![wkomut 2](images/wkomut_2.png)

3- `Enter` tuşuna bastığımda bulunduğum klasörde komut satırı açılmış oluyor.

![wkomut 3](images/wkomut_3.png)

4- Daha sonrasında `dir` komutunu çalıştırdığımda dosyalarımın orada olduğu görülebilir.

![wkomut 4](images/wkomut_4.png)

### Linux

Kullandığınız Linux dağıtımının yanında büyük olasılıkla `gcc` derleyicisi de gelmektedir. Eğer gelmiyorsa da paket yöneticiniz yükleyebilirsiniz.

* Debian, Ubuntu, Linux Mint, Pop OS vb. için:

```bash
sudo apt install gcc
```

* Redhat, Fedora vb. için:

```bash
sudo dnf install gcc
```

### Mac OS X

`XCode`'u kurun.

---

## Tek Bir `C` Dosyasının Derlenmesi

Kaynak dosyanızın ismi `main.c` olsun. Kabukta kaynak dosyanızın olduğu yerde olduğunuza emin olduktan sonra:

```bash
gcc main.c
```

komutunu çalıştırırsınız. Bu komut genellikle `a.out` adlı çalıştırılabilir dosya oluşturur. Eğer çalıştırılabilir dosyanızın farklı bir isimde (bu örnekte `main` isminde) olmasını isiyorsanız:

```bash
gcc main.c -o main
```

komutunu çalıştırdığınızda istediğiniz isimde çalıştırılabilir dosya elde edebilirsiniz.

Daha sonrasında terminale `./main` yazarak çalıştırabilirsiniz.