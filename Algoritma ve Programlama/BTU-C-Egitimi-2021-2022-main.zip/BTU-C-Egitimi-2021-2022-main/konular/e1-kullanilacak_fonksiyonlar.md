Soruları çözerken kullanabileceğiniz bazı fonksiyonlar ve açıklamaları. Fonksiyonların parametreleri ve açıklamaları `Linux Programmer's Manuel`'dan alınmıştır.

---

* `int printf(const char *restrict format, ...)`:

`printf()` fonksiyonu `format` adlı değişkende belirtilen biçime göre çıktıyı `stdout`'a yazar. Esnek argümnlı bir fonksiyondur.

---

* `int scanf(const char *restrict format, ...)`:

`scanf()` fonksiyonu `format` parametresinde belirtilen biçime göre `stdin`'den okuma yapar. Yaptığı okumaları verilen adreslere değer olarak yazar. Eğer `stdin`'de bir veya daha fazla boşluk ('` `') veya yeni satır karakteri ('`\n`') görürse okumayı sıradaki değişkene geçirir. Yani:

```c
int a, b;
scanf("%d%d", &a, &b);
```

koduna

```text
1 2
```

girdisi verilir ise ilk önce `a` değişkenine, sonra ise `b` değişkenine alınan değerleri yazar. Bu koda girdi olarak boşlukla ayrılmış girdi yerine, yeni satır karakteri ile ayrılmış girdi verilir ise de aynı davranışı gösterir:

```text
1
2
```

---

* `int strcmp(const char *s1, const char *s2)`:

Paramatre olarak verilen iki kelimeyi (char dizisi) karşılaştırır. Eğer iki kelime eşit ise 0, ilk kelime daha küçük ise negatif değer veya ilk kelime daha büyük ise pozitif değer döndürür. `Linux Programmer's Manuel`'de verilen örnek:

```bash
$ ./string_comp ABC ABC
<str1> and <str2> are equal
$ ./string_comp ABC AB      # 'C' is ASCII 67; 'C' - '\0' = 67
<str1> is greater than <str2> (67)
$ ./string_comp ABA ABZ     # 'A' is ASCII 65; 'Z' is ASCII 90
<str1> is less than <str2> (-25)
$ ./string_comp ABJ ABC
<str1> is greater than <str2> (7)
$ ./string_comp $'\201' A   # 0201 - 0101 = 0100 (or 64 decimal)
<str1> is greater than <str2> (64)
```

---

* `int sprintf(char *restrict str, const char *restrict format, ...)`:

Fonksiyonun ilk parametresi olan `str` değişkenine verilen formatı yazar. `printf` fonksiyonuna benzer. Fakat `printf` fonksiyonundan farklı olarak sonucu `stdout`'a yazmak yerine verilen `char *` tipindeki değişkene yazar.