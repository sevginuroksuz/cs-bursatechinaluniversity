# Global ve Local Scope:

Eğer herhangi bir tanımlama, herhangi bir fonksiyonun içinde değil ise bu tanımlama `global scope`'ta yapılmıştır. Eğer herhangi bir fonksiyonun içinde ise de buna `local` tanımlama denir. `formal` tanımlamalar ise bir `global` tanımlamanın `local` tanımlamaya dönüştürülmesidir.

Örnek:

```c
#include <stdio.h>

// Global degiskenler
int x = 10, y = 20;

void local_ve_global_ornegi()
{
	// Y degiskeni fonksiyon icinde local degisken yapiliyor
	int y = 30;
	int z = 40;
	printf("Fonksiyon icinde:\n");
	printf("y: %d\nz: %d\n", y, z);
}

int main()
{
	// Ilk once main fonksiyonunda degiskenler incelenir
	printf("Main icinde:\n");
	printf("x: %d\ny: %d\n", x, y);
	// Daha sonrasinda tanimlanan fonksiyon cagirilir
	local_ve_global_ornegi();
	return 0;
}
```

Çıktı:

```text
Main icinde:
x: 10
y: 20
Fonksiyon icinde:
y: 30
z: 40
```