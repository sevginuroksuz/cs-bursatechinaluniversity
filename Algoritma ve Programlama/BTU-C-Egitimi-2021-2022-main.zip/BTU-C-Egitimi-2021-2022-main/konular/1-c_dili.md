# C Dili

![C logo](images/C_Programming_Language.png)

C derlenebilen, emirli bir programlama dilidir.

Tanımlamalı programlama dili örneği (prolog):

```pl
erkek(ali).
erkek(mehmet).

kadin(basak).
kadin(nur).

ebeveyn(ali, basak).
ebeveyn(ali, mehmet).

kiz_kardes(X, Y) :-
	kadin(X),
	ebeveyn(Z, X), ebeveyn(Z, Y).
```

[Bell labaratuvarlarında](https://simple.wikipedia.org/wiki/Bell_Labs), [Unix](https://simple.wikipedia.org/wiki/UNIX) işletim sistemini geliştirmek için 1970'lerde [Ken Thompson](https://simple.wikipedia.org/wiki/Ken_Thompson) ve [Dennis Ritchie](https://simple.wikipedia.org/wiki/Dennis_Ritchie) tarafından geliştirilmiştir.

![ken thompson](images/Ken_Thompson.jpg)
![dennis ritchie](images/Dennis_Ritchie.jpg)

`C` dili nerelerde kullanılır?

* Performans gerektiren herhangi bir yazılımda
* Düşük seviye programlama gerektiren herhangi bir yerde
* İşletim sistemleri, sürücüler
* Derleyiciler, Interpreter'lar
* Oyunlar
* Gömülü sistemler

Eski bir `C` derleyicisinden bir kod parçası ([https://www.bell-labs.com/usr/dmr/www/primevalC.html](https://www.bell-labs.com/usr/dmr/www/primevalC.html), [https://github.com/mortdeus/legacy-cc](https://github.com/mortdeus/legacy-cc)):

```c
main(argc, argv)
int argv[]; {
	extern init, flush;
	extern extdef, eof, open, creat;
	extern fout, fin, error, exit, nerror, tmpfil;

	if(argc<4) {
		error("Arg count");
		exit(1);
	}
	if((fin=open(argv[1],0))<0) {
		error("Can't find %s", argv[1]);
		exit(1);
	}
	if((fout=creat(argv[2], 017))<0) {
		error("Can't create %s", argv[2]);
		exit(1);
	}
	tmpfil = argv[3];
	init("int", 0);
	init("char", 1);
	init("float", 2);
	init("double", 3);
/*	init("long", 4);  */
	init("auto", 5);
	init("extern", 6);
	init("static", 7);
	init("goto", 10);
	init("return", 11);
	init("if", 12);
	init("while", 13);
	init("else", 14);
	init("switch", 15);
	init("case", 16);
	init("break", 17);
	init("continue", 18);
	init("do", 19);
	init("default", 20);
	while(!eof) {
		extdef();
		blkend();
	}
	flush();
	flshw();
	exit(nerror!=0);
}
```

Modern `C` kodu:

```c
#include <stdio.h>

int main() {
    printf("Hello world!\n");
    return 0;
}
```

## Basit Bir `C` Kaynak Dosyasının Yapısı

İnceleyeceğimiz kod:

```c
#include <stdio.h>

int x = 10;
// ilk programimim
int main()
{
	int y = 12;
	x *= y;
	printf("X degeri: %d\n", x);
	return 0;
}
```

Çıktı:

```text
X degeri: 120
```

Satır satır ilerleyecek olursak:

1. `stdio.h` kütüphanesinin eklenmesi. `include` anahtar kelimesi belirtilen dosyayı, kaynak dosyasında çağırıldığı satıra ekler.
2. Boş satır. Bir anlam ifade etmemektedir.
3. Global scope'da değişken tanımlanması.
4. Yorum satırı. 
5. `main` fonksiyonunun tanımlanması. `int` anahtar kelimesi ise `main` fonksiyonunun ne tür bir veri tipi döndüreceğini göstermektedir.
6. `main` fonksiyonunun gövdesinin başlayacağını bildiren süslü parantez. Kod okunabilirliğini artırmak için yeni satıra yazılmıştır.
7. `main` fonksiyonunun gövdesinde, bir değişkenin tanımlanması. Kapsamı `main` fonksiyonu ile sınırlıdır. Yani `main` fonksiyonu dışında çağırılamaz.
8. Global olan x değişkenine yeni değer atama. Yeni değere her yerden erişilebilir.
9. Standart kütüphanede olan `stdio.h` kütüphanesindeki `printf()` fonksiyonunun çağırılması.
10. `main` fonksiyonunun, işini bitirdikten sonra belirli bir değeri döndürmesi. Diğer fonksiyonlardan farklı olarak `main` fonksiyonu sonucunu işletim sistemine döndürür. Genellikle programlar başarılı olarak bittiğinde 0 değerini, başarısız olarak sonuçlandığında ise 1 gibi 0 olmayan bir değer döndürür.
11. `main` fonksiyonunun gövdesinin biteceğini bildiren süslü parantez.