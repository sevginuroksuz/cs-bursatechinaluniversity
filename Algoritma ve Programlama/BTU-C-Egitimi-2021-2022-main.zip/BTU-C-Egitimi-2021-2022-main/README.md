# Giriş

Bursa Teknik Üniversitesi 2021-2022 döneminde, alt sınıflara verdiğim C eğitimidir. Eğitimi verirken kullandığım kaynaklara ve soru çözümlerine buradan ulaşabilirsiniz.

Her konu farklı bir `.md` dosyasında anlatılmıştır ve bu dosyalara `konular/` dizininden ulaşabilirsiniz.

Soruları ve çözümlerini ise `sorular-cozumler/` dizininde bulabilirsiniz.

Derste çözülen soruların Hackerrank linki: [https://www.hackerrank.com/btu-2021-2022-c-alistirma-sorulari](https://www.hackerrank.com/btu-2021-2022-c-alistirma-sorulari)

# Lisans

[MIT Lisansı](LICENSE)