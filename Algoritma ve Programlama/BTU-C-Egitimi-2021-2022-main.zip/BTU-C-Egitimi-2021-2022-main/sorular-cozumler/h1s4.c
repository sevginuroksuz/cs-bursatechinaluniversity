#include <stdio.h>
#include <string.h>

int main()
{
	int n;
	scanf("%d", &n);
	char o[31], s[100][31];
	int a[30], not = -1;
	scanf("%s", o); // aranacak ogrenci

	// ana algoritma
	for (int i = 0; i < n; i++) {
		scanf("%s%d", s[i], &a[i]);
		if (strcmp(o, s[i]) == 0) {
			not = a[i];
		}
	}
	printf("%d\n", not);
	return 0;
}
