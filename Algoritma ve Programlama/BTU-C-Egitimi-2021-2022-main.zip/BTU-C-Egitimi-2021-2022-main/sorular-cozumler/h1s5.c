#include <stdio.h>
#include <string.h>

int main()
{
	int n;
	scanf("%d", &n);
	char o[31];
	scanf("%s", o);
	int o_len = strlen(o); // ogrencinin isminin uzunlugu

	// ana algoritma
	for (int i = 0; i < o_len; i++) {
		o[i] += 3;
		if (o[i] > 'z') {
			int tmp = o[i] - 'z';
			o[i] = 'a' + tmp - 1;
		}
	}
	int var_mi = 0;
	for (int i = 0; i < n; i++) {
		char s[31];
		scanf("%s", s);
		if (strcmp(o, s) == 0) {
			var_mi = 1;
		}
	}
	printf("%d\n", var_mi);
	return 0;
}
