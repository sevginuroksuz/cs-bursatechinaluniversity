#include <stdio.h>

int main()
{
	int k;
	scanf("%d", &k);
	k *= 2;
	printf("%d\n", k);
	return 0;
}
