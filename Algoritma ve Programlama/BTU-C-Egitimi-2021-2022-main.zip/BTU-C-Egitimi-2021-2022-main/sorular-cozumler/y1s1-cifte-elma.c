#include <stdio.h>

int main()
{
    int k;
    scanf("%d", &k);
    if (k == 2)
        printf("HAYIR\n");
    else if (k % 2 == 0)
        printf("EVET\n");
    else
        printf("HAYIR\n");
    return 0;
}
