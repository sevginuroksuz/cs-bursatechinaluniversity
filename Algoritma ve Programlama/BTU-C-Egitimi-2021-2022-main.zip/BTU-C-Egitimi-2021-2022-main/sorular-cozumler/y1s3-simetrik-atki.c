#include <stdio.h>
#include <stdint.h>
#include <limits.h>

int min(int a, int b)
{
    return (a < b)? a: b;
}

int main()
{
    int n, ansr = INT_MAX;
    char s[21];
    scanf("%d%s", &n, s);
    for (char a = 'a'; a <= 'z'; a++) {
        int l = 0, r = n - 1, ans = 0;
        while (l < r) {
            if (s[l] == s[r]) {
                l++;
                r--;
            }
            else if (s[l] == a) {
                l++;
                ans++;
            }
            else if (s[r] == a) {
                r--;
                ans++;
            }
            else {
                ans = ansr;
                break;
            }
        }
        ansr = min(ansr, ans);
    }
    printf("%d\n", ansr);
    return 0;
}
