#include <stdio.h>

int main() {
	int k, a, b, c;
	scanf("%d%d%d%d", &k, &a, &b, &c);
	int toplam = 0;
	toplam += a + b + c;
	if (toplam <= k) {
		printf("EVET\n");
	}
	else {
		printf("HAYIR\n");
	}
	return 0;
}
