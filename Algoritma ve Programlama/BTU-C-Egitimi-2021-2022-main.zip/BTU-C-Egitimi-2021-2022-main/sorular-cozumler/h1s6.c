#include <stdio.h>

int main()
{
	int n;
	scanf("%d", &n);
	int bosluk = n - 1;

	// ana algoritma
	for (int i = 0; i < n; i++) {
		// soldaki bosluklar
		for (int j = 0; j < bosluk; j++) {
			printf(" ");
		}
		bosluk--;

		// harfler
		for (int j = 0; j < 2 * i + 1; j++) {
			printf("%c", 'a' + i);
		}
		printf("\n");
	}
	return 0;
}
