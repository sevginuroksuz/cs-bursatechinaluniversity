#include <stdio.h>
#include <limits.h>

int main() {
    int a[6][6];
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++)
            scanf("%d", &a[i][j]);
    int ans = INT_MIN;
    for (int i = 1; i < 5; i++) {
        for (int j = 1; j < 5; j++) {
        int x = 0;
            x += a[i - 1][j - 1] + a[i - 1][j] + a[i - 1][j + 1];
            x += a[i][j];
            x += a[i + 1][j - 1] + a[i + 1][j] + a[i + 1][j + 1];
        ans = (ans > x) ? ans: x;
        }
    }
    printf("%d\n", ans);
    return 0;
}
