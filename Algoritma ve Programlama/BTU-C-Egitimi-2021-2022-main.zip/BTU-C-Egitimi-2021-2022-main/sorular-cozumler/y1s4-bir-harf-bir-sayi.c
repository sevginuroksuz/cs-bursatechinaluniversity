#include <stdio.h>
#include <stdint.h>
#include <limits.h>
#include <string.h>

int main()
{
    char s[100];
    scanf("%s", s);
    int len = strlen(s);
    int a[26], b[26];
    memset(a, 0, sizeof(int) * 26);
    memset(b, 0, sizeof(int) * 26);
    for (int i = 0; i < len; i++) {
        if (s[i] >= 'A' && s[i] <= 'Z')
            s[i] = s[i] - 'A' + 'a';
    }
    for (int i = 0; i < len; i++) {
        a[s[i] - 'a']++;
    }
    for (int i = 0; i < len; i++) {
        if (b[s[i] - 'a'] == 0) {
            printf("%c%d", s[i], a[s[i] - 'a']);
            b[s[i] - 'a'] = 1;
        }
    }
    printf("\n");
    return 0;
}
