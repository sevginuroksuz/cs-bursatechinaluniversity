#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int randomSayiUret()
{
    srand(time(NULL));
    return (rand()%3)+1;
}
int Hesapla(int c1, int c2)
{
    if (c1 == c2)
    {
        return -1;
    }
    else if (c1 == 1 && c2 == 3)
    {
        return 1;
    }
    else if (c2 == 2 && c1 == 3)
    {
        return 0;
    }
    else if (c1 == 2 && c2 == 1)
    {
        return 1;
    }
    else if (c2 == 2 && c1 == 1)
    {
        return 0;
    }
    else if (c1 ==3 && c2 == 2)
    {
        return 1;
    }
    else if (c2 == 3 && c1 == 2)
    {
        return 0;
    }
}
int main()
{
    int oyuncuSkor = 0, bilgisayarSkor = 0, temp;
    int oyuncuDeger, bilgisayarDeger;
    int dict[] = {1, 2, 3};
    int bilgisayarSecim[5];
    int oyuncuSecim[5];
    printf("\tOyuna Hosgeldiniz\n");
    for (int i = 0; i < 100; i++)
    {
        printf("Tas icin 1'e Kagit icin 2'ye Makas icin 3'e basiniz.\n\n");
        printf("Sayi giriniz: ");
        scanf("%d", &temp);
        oyuncuDeger = dict[temp - 1];
        printf("Sizin seciminiz:%d\n", oyuncuDeger);
        bilgisayarDeger =randomSayiUret();
        printf("Bilgisayarin secimi: %d\n", bilgisayarDeger);
        if (Hesapla(bilgisayarDeger, oyuncuDeger) == 1)
        {
            bilgisayarSkor++;
            bilgisayarSecim[i] = bilgisayarDeger;
        }
		else if(Hesapla(bilgisayarDeger, oyuncuDeger) == 0)
        {
            oyuncuSkor++;
            oyuncuSecim[i] = oyuncuDeger;
        }

        if(oyuncuSkor == 5 || bilgisayarSkor == 5) {
        	i = 100;
		}
    }
    printf("   SONUC  \n");
    printf("  Oyuncu  Bilgisayar \n");
    printf("   %d      %d     \n\n", oyuncuSkor, bilgisayarSkor);
    if (oyuncuSkor > bilgisayarSkor)
    {
        printf("\tKAZANDINIZ\n");
    }
    else if (oyuncuSkor < bilgisayarSkor)
    {
        printf("\tBILGISAYAR KAZANDI\n");
    }


    return 0;
}
