#!/bin/sh
echo "what is your name?"
read ad
echo "How do you do, $ad?"
read durum
echo "I am $durum too!"
echo $0
