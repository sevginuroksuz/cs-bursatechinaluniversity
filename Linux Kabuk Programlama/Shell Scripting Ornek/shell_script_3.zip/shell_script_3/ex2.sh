#!/bin/sh
val=`expr 2 + 2`
echo "Total value : $val"
