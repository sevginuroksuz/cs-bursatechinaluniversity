#!/bin/sh

#indis ile tanımlama

NAME[0]="Zara"
NAME[1]="Qadir"
NAME[2]="Mahnaz"
NAME[3]="Ayan"
NAME[4]="Daisy"

#  tek satırda tanımlama
# atama operatörü dizi adı ve parantez ile bitişecek!!
iller=( istanbul ankara izmir bursa )

# elemanlara erişim
echo "First Index: ${NAME[0]}"
echo "Second Index: ${NAME[1]}"
echo "İller dizisinin ilk elemanı: ${iller[0]}"

# bütün elemanlara erişim  * veya @ her ikiside doğru
echo "Name dizisi elemanları: ${NAME[*]}"
echo "iller dizisi elemanları: ${iller[@]}"

