#!/bin/sh
a=5
b=4

val=`expr $a + $b`
echo "Toplam : $val"


