#!/bin/bash
# Define your function here

Hello () {
 echo "Merhaba Dünya"
}

# Invoke your function
Hello

