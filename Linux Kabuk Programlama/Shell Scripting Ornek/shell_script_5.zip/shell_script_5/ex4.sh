#!/bin/sh

# fonksiyonu tanımla
Hello () {
 echo "Hello $1 $2"
 return 10
}

# fonksiyonu cagir
Hello Ali Veli

# fonksiyondan dönen değeri al
ret=$?
echo "Dönen değer $ret"
