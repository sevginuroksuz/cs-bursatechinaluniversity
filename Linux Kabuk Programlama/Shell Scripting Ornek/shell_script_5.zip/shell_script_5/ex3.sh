#!/bin/bash
# Define your function here

Hello () {
 echo "Merhaba $1 $2"
}

# Invoke your function
Hello Ahmet Ayşe

