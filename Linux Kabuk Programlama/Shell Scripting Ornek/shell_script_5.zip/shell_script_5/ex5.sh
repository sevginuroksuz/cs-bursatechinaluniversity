#!/bin/sh

#  bir fonksiyondan baska fonksiyon cagir
number_one () {
 echo "This is the first function speaking..."
 number_two
}

# bu ikinci fonksiyon
number_two () {
 echo "This is now the second function speaking..."
}

#  birinci fonksiyonu cagir
number_one
