#!/bin/bash

whiptail --textbox istiklal.txt 10 70 --scrolltext


