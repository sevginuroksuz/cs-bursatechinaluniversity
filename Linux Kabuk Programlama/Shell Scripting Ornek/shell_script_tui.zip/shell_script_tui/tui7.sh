#!/bin/bash

NAME=$(whiptail --inputbox "Please enter your name" 10 50 3>&1 1>&2 2>&3)
echo "name: $NAME"


