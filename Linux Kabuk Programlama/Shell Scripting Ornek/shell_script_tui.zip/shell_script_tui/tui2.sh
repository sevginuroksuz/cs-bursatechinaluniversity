#!/bin/bash

whiptail --title "Pencere Basligi" --msgbox "This is a message in a message box." 10 50


