#!/bin/bash

if (whiptail --yesno "Are you sure?" 10 50) then
  echo "Yes I am sure!"
else
  echo "No I am not sure!"
fi

