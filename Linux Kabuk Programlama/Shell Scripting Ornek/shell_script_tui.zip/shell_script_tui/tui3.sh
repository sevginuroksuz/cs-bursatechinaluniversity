#!/bin/bash

# 3d butonlu diyalog (--fb)
whiptail --fb --title "Pencere Basligi" --msgbox "This is a message in a message box." 10 50


