#!/bin/bash

CHOICE=$(whiptail --title "Test Checklist Dialog" --checklist \
"Choose preferred Linux distros" 15 60 4 \
"debian" "Venerable Debian" ON \
"ubuntu" "Popular Ubuntu" OFF \
"centos" "Stable CentOS" ON \
"mint" "Rising Star Mint" OFF 3>&1 1>&2 2>&3)

if [ -z "$CHOICE" ]
then
  echo "No option was chosen (user hit Cancel)"
else
  echo "The user chose $CHOICE"
fi

