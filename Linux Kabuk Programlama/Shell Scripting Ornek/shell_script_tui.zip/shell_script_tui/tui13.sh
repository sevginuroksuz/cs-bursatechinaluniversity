#!/bin/bash
{
    for i in {0..100..10} 
            do
        sleep 1
        echo $i
    done
} | whiptail --gauge "Please wait while installing" 6 60 0

