#!/bin/bash
CHOICE=$(whiptail --title "Test Checklist Dialog" --radiolist \
"What is the Linux distro of your choice?" 15 60 4 \
"debian" "Venerable Debian" ON \
"ubuntu" "Popular Ubuntu" OFF \
"centos" "Stable CentOS" OFF \
"mint" "Rising Star Mint" OFF 3>&1 1>&2 2>&3)

if [ -z "$CHOICE" ]
then
  echo "No option was chosen (user hit Cancel)"
else
  echo "The user chose $CHOICE"
fi

