#!/bin/sh
whiptail --msgbox "This is a message in a message box." 10 50
