#!/bin/bash

PASSWORD=$(whiptail --passwordbox "Please enter your password" 10 50 3>&1 1>&2 2>&3)

echo "name: $PASSWORD "

