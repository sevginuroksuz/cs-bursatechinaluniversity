#!/bin/bash
# Buton adlaını değiştir

if (whiptail --title "Kahve Secimi" --yes-button "Orta" --no-button "Sade"  --yesno "Kahvenizi nasil alirsiniz?" 10 60) then
    echo "Orta sekerli hazirliyorum"
else
    echo "Sade hazirliyorum."
fi

