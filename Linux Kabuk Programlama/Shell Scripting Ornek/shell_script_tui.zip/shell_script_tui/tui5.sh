#!/bin/bash

# varsayılan durumda no seçili olarak gelsin

if (whiptail --yesno --defaultno "Are you sure?" 10 50) then
  echo "Yes I am sure!"
else
  echo "No I am not sure!"
fi

