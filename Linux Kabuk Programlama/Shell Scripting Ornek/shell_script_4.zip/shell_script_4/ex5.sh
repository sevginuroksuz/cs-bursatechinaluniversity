#!/bin/sh

for FILE in $HOME/*
do
 echo $FILE
done

